# SPDX-License-Identifier: GPL-3.0-or-later
"""Operators: fill the cache from a 3D Viewport, then play it on a fixed clock."""

import time

import bpy
from bpy.props import BoolProperty

from . import capture, player, store
from .ui import get_prefs

FILL_SLICE = 0.1    # seconds of caching per timer tick, so Esc stays responsive
TIMER_STEP = 0.001  # fine ticks; which frame shows comes from the clock, not the tick count

# Keys that never stop playback.
_PASS_KEYS = {
    'WHEELUPMOUSE', 'WHEELDOWNMOUSE', 'TRACKPADPAN', 'TRACKPADZOOM',
    'LEFT_SHIFT', 'RIGHT_SHIFT', 'LEFT_CTRL', 'RIGHT_CTRL', 'LEFT_ALT', 'RIGHT_ALT', 'OSKEY',
}

_PLAY_HINT = "Cache Play   ·   Space: pause / resume   ·   ← →: step   ·   Esc or click: stop"


def scene_range(scene):
    if scene.use_preview_range:
        return scene.frame_preview_start, scene.frame_preview_end
    return scene.frame_start, scene.frame_end


class CACHEPLAY_OT_preview(bpy.types.Operator):
    bl_idname = "cacheplay.preview"
    bl_label = "Cache & Play"
    bl_description = (
        "Render every frame of the range from this viewport once, "
        "then play the stored pictures at exactly the scene frame rate"
    )

    fill_only: BoolProperty(
        name="Cache Only",
        description="Fill the cache without playing it",
        default=False,
        options={'SKIP_SAVE'},
    )

    @classmethod
    def poll(cls, context):
        return not (player.state.active or player.state.filling)

    def invoke(self, context, event):
        found = capture.find_view3d(context)
        if found is None:
            self.report({'ERROR'}, "Cache Play needs a 3D Viewport")
            return {'CANCELLED'}
        area, region, space = found
        scene = context.scene
        settings = scene.cache_play
        if context.screen.is_animation_playing:
            bpy.ops.screen.animation_cancel(restore_frame=False)

        try:
            self._capturer = capture.Capturer(context, region, space, settings.preview_size)
        except Exception as ex:
            self.report({'ERROR'}, f"Cache Play could not create its offscreen buffer: {ex}")
            return {'CANCELLED'}
        cap = self._capturer
        cache = store.frame_cache
        cache.prepare(cap.key, scene.name, cap.width, cap.height, settings.storage, cap.mode)

        first, last = scene_range(scene)
        self._range = list(range(first, last + 1))
        todo = [f for f in self._range if f not in cache.frames]
        limit = int(get_prefs(context).memory_limit_gb * 1024 ** 3)
        room = max(0, limit // cache.frame_bytes - len(cache.frames))
        self._truncated = len(todo) > room
        self._todo = todo[:room]
        self._total = len(self._todo)
        self._done = 0
        self._area = area
        self._orig_frame = scene.frame_current
        self._timer = None

        if not self._todo:
            self._free_capturer()
            if self.fill_only:
                if self._truncated:
                    self.report({'WARNING'}, "Memory limit reached, nothing more can be cached")
                else:
                    self.report({'INFO'}, "Range is already cached")
                return {'FINISHED'}

        wm = context.window_manager
        self._timer = wm.event_timer_add(TIMER_STEP, window=context.window)
        wm.modal_handler_add(self)
        if self._todo:
            self._begin_fill(context)
        elif not self._begin_play(context):
            self._finish(context)
            return {'CANCELLED'}
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        state = player.state
        if state.filling:
            return self._modal_fill(context, event)
        if state.active:
            return self._modal_play(context, event)
        self._finish(context)
        return {'FINISHED'}

    def cancel(self, context):
        # Blender is closing the operator (file load, window closed): clean up, touch nothing else.
        self._free_capturer()
        if player.state.filling:
            context.window_manager.progress_end()
        player.state.stop()
        player.state.reset()
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None

    # Filling ----------------------------------------------------------------

    def _begin_fill(self, context):
        player.state.filling = True
        context.window_manager.progress_begin(0, self._total)
        self._area.header_text_set(f"Cache Play: caching {self._total} frames   ·   Esc to stop")

    def _modal_fill(self, context, event):
        if event.type == 'ESC' and event.value == 'PRESS':
            self._end_fill(context)
            self.report({'INFO'}, f"Caching stopped, {self._done} frames cached")
            self._finish(context)
            return {'FINISHED'}
        if event.type == 'TIMER':
            try:
                done = self._fill_step(context)
            except Exception as ex:
                self._end_fill(context)
                self._finish(context)
                self.report({'ERROR'}, f"Cache Play failed while caching: {ex}")
                return {'CANCELLED'}
            if done:
                self._end_fill(context)
                if self.fill_only or not self._begin_play(context):
                    self.report({'INFO'}, f"Cached {self._done} frames")
                    self._finish(context)
                    return {'FINISHED'}
            return {'PASS_THROUGH'}
        # Block clicks and keys while caching so nothing is edited halfway.
        return {'RUNNING_MODAL'} if event.value == 'PRESS' else {'PASS_THROUGH'}

    def _fill_step(self, context):
        """Cache frames for up to FILL_SLICE seconds. Returns True when all are done."""
        scene = context.scene
        cache = store.frame_cache
        deadline = time.perf_counter() + FILL_SLICE
        while self._todo:
            frame = self._todo.pop(0)
            scene.frame_set(frame)
            cache.put(frame, self._capturer.capture(context.evaluated_depsgraph_get()))
            self._done += 1
            if time.perf_counter() >= deadline:
                break
        context.window_manager.progress_update(self._done)
        self._area.header_text_set(
            f"Cache Play: cached {self._done} of {self._total} frames   ·   Esc to stop"
        )
        store.tag_time_editors()
        return not self._todo

    def _end_fill(self, context):
        self._free_capturer()
        context.window_manager.progress_end()
        self._area.header_text_set(None)
        context.scene.frame_set(self._orig_frame)
        player.state.filling = False
        player.state.suppress(0.5)

    def _free_capturer(self):
        capturer = getattr(self, "_capturer", None)
        if capturer is not None:
            capturer.free()
            self._capturer = None

    # Playing ----------------------------------------------------------------

    def _begin_play(self, context):
        cache = store.frame_cache
        frames = [f for f in self._range if f in cache.frames]
        if not frames:
            self.report({'WARNING'}, "Nothing cached to play. Is the memory limit too low?")
            return False
        scene = context.scene
        fps = scene.render.fps / scene.render.fps_base
        current = scene.frame_current
        start = frames.index(current) if current in frames else 0
        if start == len(frames) - 1:
            start = 0
        player.state.start(self._area.as_pointer(), frames, fps, start, time.perf_counter())
        context.workspace.status_text_set(_PLAY_HINT)
        if self._truncated:
            self.report(
                {'WARNING'},
                f"Memory limit reached: playing {len(frames)} of {len(self._range)} frames",
            )
        self._redraw()
        return True

    def _modal_play(self, context, event):
        state = player.state
        now = time.perf_counter()
        if event.type == 'TIMER':
            if not state.advance(now, context.scene.cache_play.loop):
                self._finish(context)
                return {'FINISHED'}
            if state.dirty:
                self._redraw()
            return {'PASS_THROUGH'}
        if event.value != 'PRESS' or event.type in _PASS_KEYS:
            return {'PASS_THROUGH'}
        if event.type == 'SPACE':
            state.set_paused(not state.paused, now)
            self._redraw()
            return {'RUNNING_MODAL'}
        if event.type in {'LEFT_ARROW', 'RIGHT_ARROW'}:
            state.step(1 if event.type == 'RIGHT_ARROW' else -1, now)
            self._redraw()
            return {'RUNNING_MODAL'}
        # Any other key or click stops playback, like After Effects. The event is used up,
        # so a click on a button only stops and does not also press the button.
        self._finish(context)
        return {'FINISHED'}

    def _redraw(self):
        player.state.dirty = False
        self._area.tag_redraw()
        store.tag_time_editors()

    def _finish(self, context):
        if self._timer is not None:
            context.window_manager.event_timer_remove(self._timer)
            self._timer = None
        state = player.state
        jump_to = state.frame if state.active and get_prefs(context).jump_on_stop else None
        was_active = state.active
        state.stop()
        if was_active:
            context.workspace.status_text_set(None)
        scene = context.scene
        if jump_to is not None and jump_to != scene.frame_current:
            state.suppress(0.5)
            scene.frame_set(jump_to)
        self._area.tag_redraw()
        store.tag_time_editors()


class CACHEPLAY_OT_clear(bpy.types.Operator):
    bl_idname = "cacheplay.clear"
    bl_label = "Clear Cache"
    bl_description = "Throw away all cached frames"

    @classmethod
    def poll(cls, context):
        return bool(store.frame_cache.frames) and not (player.state.active or player.state.filling)

    def execute(self, context):
        store.frame_cache.clear()
        store.tag_time_editors()
        return {'FINISHED'}


classes = (CACHEPLAY_OT_preview, CACHEPLAY_OT_clear)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
