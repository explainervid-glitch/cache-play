# SPDX-License-Identifier: GPL-3.0-or-later
"""Frame storage (v1: RAM or GPU memory, no disk) and cache invalidation."""

import time

import bpy
import gpu
import numpy as np
from bpy.app.handlers import persistent
from gpu_extras.batch import batch_for_shader

from . import player

PRESETS = (
    ('FULL', "Full", "Render resolution, capped to fit inside 1920×1080 (1080×1920 for vertical)"),
    ('HALF', "Half", "Half of Full"),
    ('THIRD', "Third", "A third of Full"),
    ('QUARTER', "Quarter", "A quarter of Full"),
)
_DIVISORS = {'FULL': 1, 'HALF': 2, 'THIRD': 3, 'QUARTER': 4}


def full_size(width, height):
    """Fit (width, height) inside 1920×1080, or 1080×1920 when taller than wide. Never upscale."""
    box_w, box_h = (1920, 1080) if width >= height else (1080, 1920)
    scale = min(1.0, box_w / width, box_h / height)
    return max(1, round(width * scale)), max(1, round(height * scale))


def preview_size(width, height, preset):
    full_w, full_h = full_size(width, height)
    divisor = _DIVISORS[preset]
    return max(16, round(full_w / divisor)), max(16, round(full_h / divisor))


# Packed pixels
# -------------
# gpu.types.GPUTexture only accepts FLOAT buffers, and converting 8-bit colour to floats
# for every frame would cost time and 4x the memory. Instead each RGBA8 pixel's R, G and B
# bytes are stored in the low 24 bits of a float32 whose top bits are fixed at 0x40000000.
# Every such value is a normal float (2.0 to 8.0), so it uploads to an R32F texture bit for
# bit, and a small shader unpacks the bytes again. Still 4 bytes per pixel; alpha is dropped
# because viewport captures are opaque.

_PACK_BASE = np.uint32(0x40000000)
_RGB_MASK = np.uint32(0x00FFFFFF)

_DECODE_VERT = "void main() { uv = pos * 0.5 + 0.5; gl_Position = vec4(pos, 0.0, 1.0); }"
_DECODE_FRAG = """
void main()
{
  ivec2 texel = ivec2(uv * vec2(textureSize(packed_rgb, 0)));
  uint bits = floatBitsToUint(texelFetch(packed_rgb, texel, 0).r);
  frag_color = vec4(float(bits & 0xFFu), float((bits >> 8u) & 0xFFu), float((bits >> 16u) & 0xFFu), 255.0) / 255.0;
}
"""

_decoder = None  # (shader, batch), built on first use because it needs a GPU context


def pack_pixels(pixels):
    """RGBA8 gpu.types.Buffer -> FLOAT gpu.types.Buffer with one packed float per pixel."""
    words = np.frombuffer(pixels, dtype=np.uint32)
    packed = (words & _RGB_MASK) | _PACK_BASE
    return gpu.types.Buffer('FLOAT', len(packed), packed.view(np.float32))


def _decoder_shader():
    global _decoder
    if _decoder is None:
        interface = gpu.types.GPUStageInterfaceInfo("cache_play_decode_iface")
        interface.smooth('VEC2', "uv")
        info = gpu.types.GPUShaderCreateInfo()
        info.sampler(0, 'FLOAT_2D', "packed_rgb")
        info.vertex_in(0, 'VEC2', "pos")
        info.vertex_out(interface)
        info.fragment_out(0, 'VEC4', "frag_color")
        info.vertex_source(_DECODE_VERT)
        info.fragment_source(_DECODE_FRAG)
        shader = gpu.shader.create_from_info(info)
        batch = batch_for_shader(
            shader, 'TRIS', {"pos": ((-1, -1), (1, -1), (1, 1), (-1, 1))}, indices=((0, 1, 2), (0, 2, 3)),
        )
        _decoder = (shader, batch)
    return _decoder


def _packed_texture(width, height, packed):
    return gpu.types.GPUTexture((width, height), format='R32F', data=packed)


class FrameCache:
    """Cached pictures for one view of one scene, keyed by frame number."""

    def __init__(self):
        self.key = None
        self.scene_name = ""
        self.mode = 'CAMERA'
        self.width = 0
        self.height = 0
        self.storage = 'RAM'
        # frame -> packed FLOAT gpu.types.Buffer (RAM) or R32F gpu.types.GPUTexture (VRAM)
        self.frames = {}
        self._display = None       # GPUOffScreen holding the unpacked frame being shown
        self._display_frame = None

    @property
    def frame_bytes(self):
        return self.width * self.height * 4

    @property
    def total_bytes(self):
        return self.frame_bytes * len(self.frames)

    def clear(self):
        self.frames.clear()
        self._display = None
        self._display_frame = None
        self.key = None

    def prepare(self, key, scene_name, width, height, storage, mode):
        """Make the cache match key. Returns True when old frames were thrown away."""
        full_key = (key, storage)
        if full_key == self.key:
            return False
        had_frames = bool(self.frames)
        self.clear()
        self.key = full_key
        self.scene_name = scene_name
        self.width = width
        self.height = height
        self.storage = storage
        self.mode = mode
        return had_frames

    def put(self, frame, pixels):
        """Store RGBA8 pixels (a UBYTE gpu.types.Buffer) for frame."""
        packed = pack_pixels(pixels)
        if self.storage == 'VRAM':
            packed = _packed_texture(self.width, self.height, packed)
        self.frames[frame] = packed

    def texture(self, frame):
        """Drawable RGBA8 texture for frame, or None. Needs a GPU context (a draw callback)."""
        item = self.frames.get(frame)
        if item is None:
            return None
        if self._display_frame != frame or self._display is None:
            if self._display is None:
                self._display = gpu.types.GPUOffScreen(self.width, self.height, format='RGBA8')
                self._display.texture_color.filter_mode(True)
            packed = item if self.storage == 'VRAM' else _packed_texture(self.width, self.height, item)
            shader, batch = _decoder_shader()
            with self._display.bind():
                gpu.state.blend_set('NONE')
                shader.uniform_sampler("packed_rgb", packed)
                batch.draw(shader)
            self._display_frame = frame
        return self._display.texture_color


frame_cache = FrameCache()


def tag_time_editors():
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type in {'DOPESHEET_EDITOR', 'GRAPH_EDITOR'}:
                area.tag_redraw()


# Simple invalidation mode: any real edit clears everything.
# Scene updates come from settings (including ours) and never clear; view, size and
# shading changes are caught by the cache key instead. Object, Collection and Action
# updates without any of the three change flags are selection changes.
_SKIP_TYPES = (bpy.types.Scene, bpy.types.WindowManager, bpy.types.Screen, bpy.types.WorkSpace)
_FLAG_ONLY_TYPES = (bpy.types.Object, bpy.types.Collection, bpy.types.Action)

# Changing frames (scrubbing, arrow keys, normal playback) also reports every animated
# object as updated, and in Blender 5.x that update can arrive before frame_change_pre.
# So an update counts as an edit only when the frame has not moved since the previous
# handler call, and not just after a frame change finished.
_FRAME_QUIET = 0.05  # seconds after frame_change_post during which updates are ignored
_last_frame = {}     # scene name -> (frame, subframe) at the previous handler call
_quiet_until = 0.0


def _frame_of(scene):
    return scene.frame_current, scene.frame_subframe


@persistent
def _on_frame_change(scene, *_args):
    global _quiet_until
    _last_frame[scene.name] = _frame_of(scene)
    _quiet_until = time.perf_counter() + _FRAME_QUIET


@persistent
def _on_depsgraph_update(scene, depsgraph):
    frame = _frame_of(scene)
    frame_moved = _last_frame.get(scene.name) != frame
    _last_frame[scene.name] = frame
    if frame_moved or time.perf_counter() < _quiet_until:
        return
    if not frame_cache.frames or scene.name != frame_cache.scene_name or player.state.busy():
        return
    for update in depsgraph.updates:
        id_data = update.id
        if isinstance(id_data, _SKIP_TYPES):
            continue
        changed = update.is_updated_geometry or update.is_updated_transform or update.is_updated_shading
        if changed or not isinstance(id_data, _FLAG_ONLY_TYPES):
            frame_cache.clear()
            tag_time_editors()
            return


@persistent
def _on_load_pre(*_args):
    frame_cache.clear()
    player.state.reset()


_HANDLERS = (
    ("depsgraph_update_post", _on_depsgraph_update),
    ("frame_change_post", _on_frame_change),
    ("load_pre", _on_load_pre),
)


def register():
    for name, func in _HANDLERS:
        getattr(bpy.app.handlers, name).append(func)


def unregister():
    global _decoder
    _decoder = None
    for name, func in _HANDLERS:
        handlers = getattr(bpy.app.handlers, name)
        if func in handlers:
            handlers.remove(func)
