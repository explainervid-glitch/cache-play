# SPDX-License-Identifier: GPL-3.0-or-later
"""Cache Play: After Effects style cached preview for the 3D Viewport.

v1 keeps every frame in memory (RAM or GPU). Each frame of the range is drawn
once into an offscreen buffer, then the stored pictures are played back on our
own clock without touching scene.frame_current, so Blender never re-evaluates
the scene during playback.
"""

bl_info = {
    "name": "Cache Play",
    "author": "Zeus Animation Studio",
    "version": (0, 1, 0),
    "blender": (5, 1, 0),
    "location": "3D Viewport > Sidebar > Cache Play",
    "description": "After Effects style cached preview for the 3D Viewport",
    "category": "Animation",
}

from . import draw, ops, player, store, ui


def register():
    ui.register()
    ops.register()
    draw.register()
    store.register()


def unregister():
    store.unregister()
    draw.unregister()
    ops.unregister()
    ui.unregister()
    store.frame_cache.clear()
    player.state.reset()
