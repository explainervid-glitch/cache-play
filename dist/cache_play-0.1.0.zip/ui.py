# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings, add-on preferences and the sidebar panel."""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty

from . import capture, player, store


class CachePlaySettings(bpy.types.PropertyGroup):
    preview_size: EnumProperty(
        name="Preview Size",
        description="Size of the cached pictures. Smaller fills faster and uses less memory",
        items=store.PRESETS,
        default='HALF',
    )
    storage: EnumProperty(
        name="Storage",
        description="Where cached frames are kept",
        items=(
            ('RAM', "RAM", "System memory. Each frame is sent to the graphics card as it plays"),
            ('VRAM', "GPU", "Graphics card memory. Nothing to send while playing, but video memory is smaller"),
        ),
        default='RAM',
    )
    loop: BoolProperty(name="Loop", description="Start again at the end of the range", default=True)


class _DefaultPrefs:
    memory_limit_gb = 4.0
    jump_on_stop = True


class CachePlayPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    memory_limit_gb: FloatProperty(
        name="Memory Limit (GB)",
        description="Stop caching when the cached frames reach this size",
        default=4.0,
        min=0.25,
        soft_max=64.0,
    )
    jump_on_stop: BoolProperty(
        name="Move Playhead on Stop",
        description="When playback stops, move the scene to the frame that was showing",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "memory_limit_gb")
        layout.prop(self, "jump_on_stop")


def get_prefs(context=None):
    addon = (context or bpy.context).preferences.addons.get(__package__)
    return addon.preferences if addon is not None else _DefaultPrefs


def _megabytes(n_bytes):
    return n_bytes / (1024 * 1024)


class VIEW3D_PT_cache_play(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cache Play"
    bl_label = "Cache Play"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.cache_play

        row = layout.row()
        row.scale_y = 1.5
        row.operator("cacheplay.preview", text="Cache & Play", icon='PLAY')
        row = layout.row(align=True)
        row.operator("cacheplay.preview", text="Cache Only", icon='RENDER_ANIMATION').fill_only = True
        row.operator("cacheplay.clear", text="Clear", icon='TRASH')

        col = layout.column()
        col.prop(settings, "preview_size")
        col.row().prop(settings, "storage", expand=True)
        col.prop(settings, "loop")

        found = capture.find_view3d(context)
        box = layout.box()
        col = box.column(align=True)
        if found is not None:
            _area, region, space = found
            mode = capture.source_mode(scene, space)
            width, height = capture.capture_size(scene, region, space, settings.preview_size)
            if mode == 'CAMERA':
                col.label(text="Source: camera", icon='CAMERA_DATA')
            else:
                col.label(text="Source: this view (orbiting clears)", icon='VIEW3D')
            col.label(text=f"Size: {width}×{height}  ·  {_megabytes(width * height * 4):.1f} MB/frame")

        cache = store.frame_cache
        if cache.frames:
            col.label(
                text=f"Cached: {len(cache.frames)} frames  ·  {_megabytes(cache.total_bytes):.0f} MB",
                icon='CHECKMARK',
            )
        else:
            col.label(text="Cache is empty", icon='INFO')

        summary = player.state.last_summary
        if summary:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Last playback", icon='TIME')
            col.label(text=f"Frames shown {summary['shown']}  ·  dropped {summary['dropped']}")
            col.label(text=f"Timing jitter {summary['jitter_ms']:.2f} ms  (worst {summary['worst_ms']:.1f})")
            col.label(text=f"Redraw {summary['latency_ms']:.1f} ms  (worst {summary['latency_max_ms']:.1f})")


classes = (CachePlaySettings, CachePlayPreferences, VIEW3D_PT_cache_play)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cache_play = PointerProperty(type=CachePlaySettings)


def unregister():
    del bpy.types.Scene.cache_play
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
