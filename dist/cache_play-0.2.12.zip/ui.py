# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings, add-on preferences and the sidebar panel."""

import bpy
from bpy.props import (
    BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty,
)

from . import capture, disk, player, store


class CachePlaySettings(bpy.types.PropertyGroup):
    preview_size: EnumProperty(
        name="Preview Size",
        description="Size of the cached pictures. Smaller fills faster and uses less memory",
        items=store.PRESETS,
        default='HALF',
    )
    loop: BoolProperty(name="Loop", description="Start again at the end of the range", default=True)
    cache_when_idle: BoolProperty(
        name="Cache When Idle",
        description=(
            "Like After Effects: after a few seconds without working in Blender, fill missing frames "
            "one at a time. A key, click or wheel turn in Blender pauses it; moving the mouse and "
            "using other programs do not"
        ),
        default=False,
    )


class _DefaultPrefs:
    """Used when the add-on is loaded without being installed (development, tests)."""
    memory_limit_gb = 4.0
    use_disk_cache = True
    cache_dir = ""
    disk_limit_gb = 20.0
    idle_delay = 2.0
    jump_on_stop = True
    toolbar = 'VIEWPORT'
    toolbar_collapsed = False


class CachePlayPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    memory_limit_gb: FloatProperty(
        name="RAM Limit (GB)",
        description="Most memory the cached frames may use. With the disk cache on, older frames move out to disk",
        default=4.0,
        min=0.25,
        soft_max=64.0,
    )
    use_disk_cache: BoolProperty(
        name="Disk Cache",
        description="Save every cached frame to disk, so ranges longer than the RAM limit still play",
        default=True,
    )
    cache_dir: StringProperty(
        name="Cache Folder",
        description="Where frames are saved. Empty uses Blender's temporary folder. A fast SSD is best",
        subtype='DIR_PATH',
        default="",
    )
    disk_limit_gb: FloatProperty(
        name="Disk Limit (GB)",
        description="Stop caching when the frames on disk reach this size",
        default=20.0,
        min=1.0,
        soft_max=500.0,
    )
    idle_delay: FloatProperty(
        name="Idle Delay",
        description=(
            "Seconds without working in Blender (keys, clicks, wheel, edits) before Cache When Idle "
            "starts. Moving the mouse and using other programs do not count"
        ),
        default=2.0,
        min=0.5,
        max=30.0,
        subtype='TIME_ABSOLUTE',
        unit='TIME_ABSOLUTE',
    )
    jump_on_stop: BoolProperty(
        name="Move Playhead on Stop",
        description="When playback stops, move the scene to the frame that was showing",
        default=True,
    )
    toolbar: EnumProperty(
        name="Toolbar",
        description="Where the Cache Play buttons appear (the sidebar panel is always there too)",
        items=(
            ('VIEWPORT', "3D Viewport", "A pill at the bottom centre of each 3D Viewport; the chevron folds it away"),
            ('TIMELINE', "Timeline Header", "A bar in the Timeline header, after the Playback menu"),
            ('BOTH', "Both", "The viewport pill and the Timeline bar"),
        ),
        default='VIEWPORT',
    )
    toolbar_collapsed: BoolProperty(
        name="Toolbar Folded",
        description="The viewport toolbar is folded down to its chevron",
        default=False,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "memory_limit_gb")
        layout.prop(self, "use_disk_cache")
        col = layout.column()
        col.active = self.use_disk_cache
        col.prop(self, "cache_dir")
        col.prop(self, "disk_limit_gb")
        layout.prop(self, "idle_delay")
        layout.prop(self, "jump_on_stop")
        layout.separator()
        layout.prop(self, "toolbar")
        layout.separator()
        layout.label(text="Shortcuts")
        from . import ops  # ops imports this module, so import late
        ops.draw_keymap(layout, context)


def get_prefs(context=None):
    addon = (context or bpy.context).preferences.addons.get(__package__)
    return addon.preferences if addon is not None else _DefaultPrefs


def configure_cache(context=None):
    """Pass the current preferences on to the frame cache."""
    preferences = (context or bpy.context).preferences
    prefs = get_prefs(context)
    if prefs.cache_dir:
        base_dir = bpy.path.abspath(prefs.cache_dir)
    else:
        base_dir = disk.default_base_dir(preferences)
    store.frame_cache.configure(
        int(prefs.memory_limit_gb * 2 ** 30), int(prefs.disk_limit_gb * 2 ** 30),
        prefs.use_disk_cache, base_dir,
    )


def _megabytes(n_bytes):
    return n_bytes / (1024 * 1024)


def _draw_cache_mode_toggle(layout):
    layout.operator("cacheplay.cache_mode", text="Cache Mode", icon='FILE_MOVIE',
                    depress=player.state.cache_mode)


TIMELINE_BAR_WIDE = 1750  # Timeline width (px at 1x UI scale) from which the bar shows button text


def _cached_in_range(scene):
    """(cached frames in the scene range, frames in the range)."""
    first, last = store.scene_range(scene)
    _in_ram, cached = store.frame_cache.snapshot()
    total = last - first + 1
    return len(cached.intersection(range(first, last + 1))), total


# Timeline bar placement
# ----------------------
# The bar belongs between Blender's "Playback" drop-down and the Auto Keying button. Both
# are drawn by bl_ui's playback_controls(layout, context), which an add-on cannot add to.
# So the Dope Sheet module's reference to it is wrapped: inside, the layout is replaced by
# a stand-in that draws the bar right after the Playback popover. If a future Blender
# draws its header differently, the bar is not drawn there and the header append below
# draws it at the right end instead.

_bar = {"drawn": False}       # drawn after the Playback popover in this header redraw
_original_playback_controls = None


class _AfterPlaybackLayout:
    """Stands in for the Timeline header layout inside Blender's playback_controls()."""

    def __init__(self, layout, context):
        self._layout = layout
        self._context = context

    def __getattr__(self, name):
        return getattr(self._layout, name)

    def popover(self, *args, **kwargs):
        result = self._layout.popover(*args, **kwargs)
        if kwargs.get("panel") == "TIME_PT_playback":
            self._layout.separator()
            _draw_bar(self._layout, self._context)
            _bar["drawn"] = True
        return result


def _timeline_bar_enabled(context):
    return get_prefs(context).toolbar in {'TIMELINE', 'BOTH'}


def _playback_controls(layout, context):
    space, region = context.space_data, context.region
    if (space.type == 'DOPESHEET_EDITOR' and space.mode == 'TIMELINE' and region.type == 'HEADER'
            and _timeline_bar_enabled(context)):
        layout = _AfterPlaybackLayout(layout, context)
    _original_playback_controls(layout, context)


def _wrap_playback_controls():
    global _original_playback_controls
    from bl_ui import space_dopesheet
    if getattr(space_dopesheet, "playback_controls", None) is None:
        return
    _original_playback_controls = space_dopesheet.playback_controls
    space_dopesheet.playback_controls = _playback_controls


def _unwrap_playback_controls():
    global _original_playback_controls
    from bl_ui import space_dopesheet
    if _original_playback_controls is not None and space_dopesheet.playback_controls is _playback_controls:
        space_dopesheet.playback_controls = _original_playback_controls
    _original_playback_controls = None


def _draw_timeline_header(self, context):
    """Appended to the Dope Sheet header: Cache Mode toggle in Dope Sheet modes, and the
    Timeline bar at the right end only if it could not go after the Playback drop-down."""
    layout = self.layout
    if not _timeline_bar_enabled(context):
        return
    if context.space_data.mode != 'TIMELINE':
        layout.separator()
        _draw_cache_mode_toggle(layout)
        return
    if _bar["drawn"]:
        _bar["drawn"] = False
        return
    layout.separator()
    _draw_bar(layout, context)


def _draw_bar(layout, context):
    """The Cache Play controls laid out horizontally like transport controls."""
    settings = context.scene.cache_play
    # Blender's own Timeline header takes about 1100 px; on narrower editors the two main
    # buttons drop their text so the whole bar still fits.
    wide = context.region.width >= TIMELINE_BAR_WIDE * context.preferences.system.ui_scale

    row = layout.row(align=True)
    row.operator("cacheplay.preview", text="Cache & Play" if wide else "", icon='PLAY')
    row.operator("cacheplay.cache_mode", text="Cache Mode" if wide else "",
                 icon='FILE_MOVIE', depress=player.state.cache_mode)
    row.operator("cacheplay.clear", text="", icon='TRASH')

    cached, total = _cached_in_range(context.scene)
    problem = store.frame_cache.disk_error or store.frame_cache.full_reason
    layout.label(text=f"{cached}/{total}",
                 icon='ERROR' if problem else ('CHECKMARK' if cached == total else 'SEQ_STRIP_DUPLICATE'))

    sub = layout.row()
    sub.ui_units_x = 4 if wide else 3.2
    sub.prop(settings, "preview_size", text="")
    row = layout.row(align=True)
    row.prop(settings, "loop", text="", toggle=True, icon='FILE_REFRESH')
    row.prop(settings, "cache_when_idle", text="", toggle=True, icon='TIME')
    layout.popover(panel="DOPESHEET_PT_cache_play", text="", icon='PREFERENCES')


def _draw_details(layout, context):
    scene = context.scene
    col = layout.column(align=True)
    camera = scene.camera
    col.label(text=f"Camera: {camera.name}" if camera else "No scene camera", icon='CAMERA_DATA')
    width, height = capture.capture_size(scene, scene.cache_play.preview_size)
    col.label(text=f"{width}×{height}  ·  {_megabytes(width * height * 4):.1f} MB per frame",
              icon='IMAGE_DATA')
    stats = store.frame_cache.stats()
    col.label(text=f"RAM: {stats['ram_frames']} frames  ·  {_megabytes(stats['ram_bytes']):.0f} MB",
              icon='MEMORY')
    if get_prefs(context).use_disk_cache:
        col.label(text=f"Disk: {stats['disk_frames']} frames  ·  {_megabytes(stats['disk_bytes']):.0f} MB",
                  icon='DISK_DRIVE')
    else:
        col.label(text="Disk cache off", icon='DISK_DRIVE')
    layout.operator("preferences.addon_show", text="Limits & Folder…", icon='PREFERENCES').module = __package__


def _draw_stats(layout):
    summary = player.state.last_summary
    if not summary:
        layout.label(text="Play the cache once to measure it")
        return
    col = layout.column(align=True)
    col.label(text=f"Frames shown: {summary['shown']}")
    col.label(text=f"Dropped: {summary['dropped']}")
    col.label(text=f"Timing jitter: {summary['jitter_ms']:.2f} ms (worst {summary['worst_ms']:.1f})")
    col.label(text=f"Redraw: {summary['latency_ms']:.1f} ms (worst {summary['latency_max_ms']:.1f})")
    if summary.get("late_reads"):
        col.label(text=f"Read late from disk: {summary['late_reads']}")


def _draw_popover(layout, context, with_settings):
    """Drop-down shared by the Timeline bar and the floating toolbar."""
    row = layout.row(align=True)
    row.operator("cacheplay.preview", text="Cache Only", icon='RENDER_ANIMATION').fill_only = True
    row.operator("cacheplay.clear", text="Clear", icon='TRASH')
    if with_settings:
        # The floating toolbar only has round buttons, so its drop-down holds the settings.
        settings = context.scene.cache_play
        layout.row().prop(settings, "preview_size", expand=True)
        row = layout.row(align=True)
        row.prop(settings, "loop", toggle=True, icon='FILE_REFRESH')
        row.prop(settings, "cache_when_idle", text="Cache When Idle", toggle=True, icon='TIME')
    cached, total = _cached_in_range(context.scene)
    layout.label(text=f"{cached} of {total} frames cached", icon='CHECKMARK' if cached == total else 'INFO')
    problem = store.frame_cache.disk_error or store.frame_cache.full_reason
    if problem:
        layout.label(text=problem, icon='ERROR')
    if context.scene.cache_play.cache_when_idle:
        from . import idle  # idle imports this module, so import late
        if idle.status:
            layout.label(text=idle.status, icon='TIME')
    layout.separator()
    layout.label(text="Cache Details")
    _draw_details(layout, context)
    layout.separator()
    layout.label(text="Statistics")
    _draw_stats(layout)


class DOPESHEET_PT_cache_play(bpy.types.Panel):
    """Drop-down from the Timeline bar."""
    bl_space_type = 'DOPESHEET_EDITOR'
    bl_region_type = 'HEADER'
    bl_label = "Cache Play"
    bl_ui_units_x = 14

    def draw(self, context):
        _draw_popover(self.layout, context, with_settings=False)


class VIEW3D_PT_cache_play_popover(bpy.types.Panel):
    """Drop-down from the floating toolbar's settings button."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'HEADER'
    bl_label = "Cache Play"
    bl_ui_units_x = 14

    def draw(self, context):
        _draw_popover(self.layout, context, with_settings=True)


class VIEW3D_PT_cache_play(bpy.types.Panel):
    """Main panel: the buttons and settings used every day."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cache Play"
    bl_label = "Cache Play"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.cache_play

        row = layout.row(align=True)
        row.scale_y = 1.4
        row.operator("cacheplay.preview", text="Cache & Play", icon='PLAY')
        _draw_cache_mode_toggle(row)

        row = layout.row(align=True)
        row.operator("cacheplay.preview", text="Cache Only", icon='RENDER_ANIMATION').fill_only = True
        row.operator("cacheplay.clear", text="Clear", icon='TRASH')

        # One line that answers "how much is cached?"
        cached, total = _cached_in_range(context.scene)
        if cached == total:
            layout.label(text=f"All {total} frames cached", icon='CHECKMARK')
        elif cached:
            layout.label(text=f"{cached} of {total} frames cached", icon='SEQ_STRIP_DUPLICATE')
        else:
            layout.label(text="Nothing cached yet", icon='RADIOBUT_OFF')
        problem = store.frame_cache.disk_error or store.frame_cache.full_reason
        if problem:
            layout.label(text=problem, icon='ERROR')

        layout.row().prop(settings, "preview_size", expand=True)
        row = layout.row(align=True)
        row.prop(settings, "loop", toggle=True, icon='FILE_REFRESH')
        row.prop(settings, "cache_when_idle", text="Cache When Idle", toggle=True, icon='TIME')
        if settings.cache_when_idle:
            from . import idle  # idle imports this module, so import late
            if idle.status:
                row = layout.row()
                row.scale_y = 0.8
                row.label(text=idle.status)


class VIEW3D_PT_cache_play_storage(bpy.types.Panel):
    """Where the pictures come from and where they are kept."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cache Play"
    bl_label = "Cache Details"
    bl_parent_id = "VIEW3D_PT_cache_play"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        _draw_details(self.layout, context)


class VIEW3D_PT_cache_play_stats(bpy.types.Panel):
    """How smoothly the last cached playback ran."""
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cache Play"
    bl_label = "Statistics"
    bl_parent_id = "VIEW3D_PT_cache_play"
    bl_options = {'DEFAULT_CLOSED'}

    def draw(self, context):
        _draw_stats(self.layout)


classes = (CachePlaySettings, CachePlayPreferences, VIEW3D_PT_cache_play,
           VIEW3D_PT_cache_play_storage, VIEW3D_PT_cache_play_stats, DOPESHEET_PT_cache_play,
           VIEW3D_PT_cache_play_popover)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cache_play = PointerProperty(type=CachePlaySettings)
    bpy.types.DOPESHEET_HT_header.append(_draw_timeline_header)
    _wrap_playback_controls()


def unregister():
    _unwrap_playback_controls()
    bpy.types.DOPESHEET_HT_header.remove(_draw_timeline_header)
    del bpy.types.Scene.cache_play
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
