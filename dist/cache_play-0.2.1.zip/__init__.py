# SPDX-License-Identifier: GPL-3.0-or-later
"""Cache Play: After Effects style cached preview for the 3D Viewport.

Each frame of the range is drawn once into an offscreen buffer and stored (RAM in front
of a disk cache). The stored pictures are played back on our own clock without touching
scene.frame_current, so Blender never re-evaluates the scene during playback.
"""

bl_info = {
    "name": "Cache Play",
    "author": "Zeus Animation Studio",
    "version": (0, 2, 1),
    "blender": (5, 1, 0),
    "location": "3D Viewport > Sidebar > Cache Play",
    "description": "After Effects style cached preview for the 3D Viewport",
    "category": "Animation",
}

import atexit

from . import display, draw, idle, ops, player, store, ui


def register():
    ui.register()
    ops.register()
    draw.register()
    store.register()
    idle.register()
    atexit.register(store.frame_cache.shutdown)


def unregister():
    atexit.unregister(store.frame_cache.shutdown)
    idle.unregister()
    store.unregister()
    draw.unregister()
    ops.unregister()
    ui.unregister()
    display.unregister()
    store.frame_cache.shutdown()
    player.state.reset()
