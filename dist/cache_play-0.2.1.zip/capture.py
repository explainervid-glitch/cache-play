# SPDX-License-Identifier: GPL-3.0-or-later
"""Draw the 3D Viewport into an offscreen buffer and read the pixels back."""

import gpu

from . import store

# Viewport shading settings that change the picture without a depsgraph update.
_SHADING_ATTRS = (
    "type", "light", "color_type", "single_color", "wireframe_color_type",
    "background_type", "background_color", "studio_light", "studiolight_rotate_z",
    "studiolight_intensity", "studiolight_background_alpha", "studiolight_background_blur",
    "use_world_space_lighting", "use_scene_lights", "use_scene_world",
    "use_scene_lights_render", "use_scene_world_render", "show_xray", "xray_alpha",
    "show_shadows", "shadow_intensity", "show_cavity", "cavity_type",
    "show_object_outline", "object_outline_color", "show_specular_highlight",
    "show_backface_culling", "use_dof", "render_pass", "use_compositor",
)


def _freeze(value):
    """Turn a property value into something hashable and comparable."""
    if isinstance(value, float):
        return round(value, 5)
    if value is None or isinstance(value, (bool, int, str)):
        return value
    if isinstance(value, (set, frozenset)):
        return tuple(sorted(value))
    try:
        return tuple(_freeze(v) for v in value)
    except TypeError:
        return repr(value)


def _shading_key(space):
    shading = space.shading
    return tuple(_freeze(getattr(shading, name, None)) for name in _SHADING_ATTRS) + (
        space.overlay.show_overlays,
    )


def _color_key(scene):
    view = scene.view_settings
    return (
        view.view_transform, view.look, _freeze(view.exposure), _freeze(view.gamma),
        view.use_curve_mapping, scene.display_settings.display_device,
    )


def find_view3d(context):
    """(area, region, space) of the 3D Viewport to cache: the current one, else the biggest."""
    area = context.area
    if area is None or area.type != 'VIEW_3D':
        screen = context.screen
        areas = [a for a in screen.areas if a.type == 'VIEW_3D'] if screen else []
        if not areas:
            return None
        area = max(areas, key=lambda a: a.width * a.height)
    region, space = view3d_parts(area)
    return None if region is None else (area, region, space)


def view3d_parts(area):
    """(region, space) of a 3D Viewport area; region is None if it has no main region."""
    space = area.spaces.active
    regions = [r for r in area.regions if r.type == 'WINDOW']
    if not regions:
        return None, space
    # In quad view, use the region that owns the space's main view.
    return next((r for r in regions if r.data == space.region_3d), regions[-1]), space


def source_mode(scene, space):
    if scene.camera is not None and space.region_3d.view_perspective == 'CAMERA':
        return 'CAMERA'
    return 'VIEW'


def capture_size(scene, region, space, preset):
    if source_mode(scene, space) == 'CAMERA':
        render = scene.render
        return store.preview_size(render.resolution_x, render.resolution_y, preset)
    return store.preview_size(region.width, region.height, preset)


class Capturer:
    """Renders frames of one 3D Viewport, as it is set up right now, into pixels.

    Creating one is cheap (it only works out the cache key); the offscreen buffer is
    made on the first capture.
    """

    def __init__(self, scene, view_layer, region, space, preset):
        render = scene.render
        rv3d = space.region_3d
        self.scene = scene
        self.view_layer = view_layer
        self.region = region
        self.space = space
        self.mode = source_mode(scene, space)
        self.width, self.height = capture_size(scene, region, space, preset)
        if self.mode == 'CAMERA':
            # The camera may move, so its matrices are read per frame.
            self.view_matrix = self.projection_matrix = None
            view_key = (render.resolution_x, render.resolution_y,
                        _freeze(render.pixel_aspect_x), _freeze(render.pixel_aspect_y))
        else:
            # A free view is frozen as it is now; orbiting afterwards makes the cache stale.
            self.view_matrix = rv3d.view_matrix.copy()
            self.projection_matrix = rv3d.window_matrix.copy()
            view_key = (_freeze(self.view_matrix), _freeze(self.projection_matrix))
        self.key = (
            scene.name, self.view_layer.name, self.mode, self.width, self.height, view_key,
            render.engine, _shading_key(space), _color_key(scene),
        )
        self.offscreen = None

    def capture(self, depsgraph):
        """Draw the current (already evaluated) frame. Returns RGBA8 pixels, bottom row first."""
        scene = self.scene
        if self.mode == 'CAMERA':
            camera = scene.camera.evaluated_get(depsgraph)
            view_matrix = camera.matrix_world.normalized().inverted()
            projection_matrix = camera.calc_matrix_camera(
                depsgraph, x=self.width, y=self.height,
                scale_x=scene.render.pixel_aspect_x, scale_y=scene.render.pixel_aspect_y,
            )
        else:
            view_matrix, projection_matrix = self.view_matrix, self.projection_matrix
        if self.offscreen is None:
            self.offscreen = gpu.types.GPUOffScreen(self.width, self.height, format='RGBA8')
        self.offscreen.draw_view3d(
            scene, self.view_layer, self.space, self.region, view_matrix, projection_matrix,
            do_color_management=True, draw_background=True,
        )
        pixels = gpu.types.Buffer('UBYTE', self.width * self.height * 4)
        with self.offscreen.bind():
            framebuffer = gpu.state.active_framebuffer_get()
            framebuffer.read_color(0, 0, self.width, self.height, 4, 0, 'UBYTE', data=pixels)
        return pixels

    def free(self):
        if self.offscreen is not None:
            self.offscreen.free()
            self.offscreen = None
