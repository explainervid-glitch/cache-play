# SPDX-License-Identifier: GPL-3.0-or-later
"""Settings, add-on preferences and the sidebar panel."""

import bpy
from bpy.props import BoolProperty, EnumProperty, FloatProperty, PointerProperty, StringProperty

from . import capture, disk, player, store


class CachePlaySettings(bpy.types.PropertyGroup):
    preview_size: EnumProperty(
        name="Preview Size",
        description="Size of the cached pictures. Smaller fills faster and uses less memory",
        items=store.PRESETS,
        default='HALF',
    )
    loop: BoolProperty(name="Loop", description="Start again at the end of the range", default=True)
    cache_when_idle: BoolProperty(
        name="Cache When Idle",
        description=(
            "After a few seconds without mouse activity, fill missing frames one at a time. "
            "Stops as soon as you move the mouse"
        ),
        default=False,
    )


class _DefaultPrefs:
    """Used when the add-on is loaded without being installed (development, tests)."""
    memory_limit_gb = 4.0
    use_disk_cache = True
    cache_dir = ""
    disk_limit_gb = 20.0
    idle_delay = 3.0
    jump_on_stop = True


class CachePlayPreferences(bpy.types.AddonPreferences):
    bl_idname = __package__

    memory_limit_gb: FloatProperty(
        name="RAM Limit (GB)",
        description="Most memory the cached frames may use. With the disk cache on, older frames move out to disk",
        default=4.0,
        min=0.25,
        soft_max=64.0,
    )
    use_disk_cache: BoolProperty(
        name="Disk Cache",
        description="Save every cached frame to disk, so ranges longer than the RAM limit still play",
        default=True,
    )
    cache_dir: StringProperty(
        name="Cache Folder",
        description="Where frames are saved. Empty uses Blender's temporary folder. A fast SSD is best",
        subtype='DIR_PATH',
        default="",
    )
    disk_limit_gb: FloatProperty(
        name="Disk Limit (GB)",
        description="Stop caching when the frames on disk reach this size",
        default=20.0,
        min=1.0,
        soft_max=500.0,
    )
    idle_delay: FloatProperty(
        name="Idle Delay",
        description="Seconds without mouse activity before Cache When Idle starts",
        default=3.0,
        min=0.5,
        max=30.0,
        subtype='TIME_ABSOLUTE',
        unit='TIME_ABSOLUTE',
    )
    jump_on_stop: BoolProperty(
        name="Move Playhead on Stop",
        description="When playback stops, move the scene to the frame that was showing",
        default=True,
    )

    def draw(self, context):
        layout = self.layout
        layout.use_property_split = True
        layout.prop(self, "memory_limit_gb")
        layout.prop(self, "use_disk_cache")
        col = layout.column()
        col.active = self.use_disk_cache
        col.prop(self, "cache_dir")
        col.prop(self, "disk_limit_gb")
        layout.prop(self, "idle_delay")
        layout.prop(self, "jump_on_stop")


def get_prefs(context=None):
    addon = (context or bpy.context).preferences.addons.get(__package__)
    return addon.preferences if addon is not None else _DefaultPrefs


def configure_cache(context=None):
    """Pass the current preferences on to the frame cache."""
    preferences = (context or bpy.context).preferences
    prefs = get_prefs(context)
    if prefs.cache_dir:
        base_dir = bpy.path.abspath(prefs.cache_dir)
    else:
        base_dir = disk.default_base_dir(preferences)
    store.frame_cache.configure(
        int(prefs.memory_limit_gb * 2 ** 30), int(prefs.disk_limit_gb * 2 ** 30),
        prefs.use_disk_cache, base_dir,
    )


def _megabytes(n_bytes):
    return n_bytes / (1024 * 1024)


def _draw_cache_mode_toggle(layout):
    layout.operator("cacheplay.cache_mode", text="Cache Mode", icon='FILE_MOVIE',
                    depress=player.state.cache_mode)


def _draw_timeline_header(self, context):
    """Cache Mode toggle at the right end of the Timeline / Dope Sheet header."""
    layout = self.layout
    layout.separator()
    _draw_cache_mode_toggle(layout)


class VIEW3D_PT_cache_play(bpy.types.Panel):
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Cache Play"
    bl_label = "Cache Play"

    def draw(self, context):
        layout = self.layout
        scene = context.scene
        settings = scene.cache_play

        row = layout.row()
        row.scale_y = 1.5
        row.operator("cacheplay.preview", text="Cache & Play", icon='PLAY')
        _draw_cache_mode_toggle(layout.row())
        row = layout.row(align=True)
        row.operator("cacheplay.preview", text="Cache Only", icon='RENDER_ANIMATION').fill_only = True
        row.operator("cacheplay.clear", text="Clear", icon='TRASH')

        col = layout.column()
        col.prop(settings, "preview_size")
        col.prop(settings, "loop")
        col.prop(settings, "cache_when_idle")

        found = capture.find_view3d(context)
        box = layout.box()
        col = box.column(align=True)
        if found is not None:
            _area, region, space = found
            mode = capture.source_mode(scene, space)
            width, height = capture.capture_size(scene, region, space, settings.preview_size)
            if mode == 'CAMERA':
                col.label(text="Source: camera", icon='CAMERA_DATA')
            else:
                col.label(text="Source: this view (orbiting clears)", icon='VIEW3D')
            col.label(text=f"Size: {width}×{height}  ·  {_megabytes(width * height * 4):.1f} MB/frame")

        cache = store.frame_cache
        stats = cache.stats()
        if stats["frames"]:
            col.label(text=f"Cached: {stats['frames']} frames", icon='CHECKMARK')
            col.label(
                text=f"RAM: {stats['ram_frames']} frames  ·  {_megabytes(stats['ram_bytes']):.0f} MB",
                icon='MEMORY',
            )
            if cache.folder is not None:
                col.label(
                    text=f"Disk: {stats['disk_frames']} frames  ·  {_megabytes(stats['disk_bytes']):.0f} MB",
                    icon='DISK_DRIVE',
                )
        else:
            col.label(text="Cache is empty", icon='INFO')
        if not get_prefs(context).use_disk_cache:
            col.label(text="Disk cache is off (Preferences)", icon='DISK_DRIVE')
        problem = cache.disk_error or cache.full_reason
        if problem:
            col.label(text=problem, icon='ERROR')

        summary = player.state.last_summary
        if summary:
            box = layout.box()
            col = box.column(align=True)
            col.label(text="Last playback", icon='TIME')
            col.label(text=f"Frames shown {summary['shown']}  ·  dropped {summary['dropped']}")
            col.label(text=f"Timing jitter {summary['jitter_ms']:.2f} ms  (worst {summary['worst_ms']:.1f})")
            col.label(text=f"Redraw {summary['latency_ms']:.1f} ms  (worst {summary['latency_max_ms']:.1f})")
            if summary.get("late_reads"):
                col.label(text=f"Frames read late from disk: {summary['late_reads']}")


classes = (CachePlaySettings, CachePlayPreferences, VIEW3D_PT_cache_play)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.cache_play = PointerProperty(type=CachePlaySettings)
    bpy.types.DOPESHEET_HT_header.append(_draw_timeline_header)


def unregister():
    bpy.types.DOPESHEET_HT_header.remove(_draw_timeline_header)
    del bpy.types.Scene.cache_play
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
