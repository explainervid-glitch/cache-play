# SPDX-License-Identifier: GPL-3.0-or-later
"""Cache When Idle: fill missing frames one at a time while nobody is working.

Idle means no keyboard or mouse input for a few seconds. Blender's Python API has no
such signal, so the operating system is asked (Windows: GetLastInputInfo, macOS: Quartz).
Edits, frame changes and view changes inside Blender also count as activity; on other
systems they are the only signal.

Each step caches one frame: jump the scene to a missing frame, capture it, jump straight
back. Nothing redraws in between, so the playhead never visibly moves. A step costs two
scene evaluations, so input during one can feel like a short hitch.
"""

import ctypes
import sys
import time

import bpy
from bpy.app.handlers import persistent

from . import capture, player, store
from .ops import scene_range
from .ui import configure_cache, get_prefs

CHECK_INTERVAL = 0.25         # seconds between checks while not idle
BACKGROUND_MODAL_AGE = 20.0   # modal operators running longer than this are other add-ons' helpers
_ALLOWED_MODES = {'OBJECT', 'POSE'}
_BLOCKING_JOBS = ('RENDER', 'OBJECT_BAKE', 'COMPOSITE')

_last_activity = 0.0
_last_view = None        # view matrix of the target viewport at the previous check
_offscreen_owner = None  # Capturer whose offscreen buffer is reused between steps
_modal_seen = {}         # modal operator pointer -> when first seen


def touch():
    global _last_activity
    _last_activity = time.perf_counter()


def _make_os_idle_seconds():
    """A function returning seconds since the last keyboard or mouse input, or None."""
    try:
        if sys.platform == "win32":
            class LastInputInfo(ctypes.Structure):
                _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

            user32, kernel32 = ctypes.windll.user32, ctypes.windll.kernel32
            kernel32.GetTickCount.restype = ctypes.c_uint

            def seconds():
                info = LastInputInfo(ctypes.sizeof(LastInputInfo), 0)
                if not user32.GetLastInputInfo(ctypes.byref(info)):
                    return None
                return ((kernel32.GetTickCount() - info.dwTime) & 0xFFFFFFFF) / 1000.0
            return seconds
        if sys.platform == "darwin":
            quartz = ctypes.CDLL(
                "/System/Library/Frameworks/ApplicationServices.framework/ApplicationServices")
            since = quartz.CGEventSourceSecondsSinceLastEventType
            since.restype = ctypes.c_double
            since.argtypes = (ctypes.c_uint32, ctypes.c_uint32)
            # kCGEventSourceStateHIDSystemState, kCGAnyInputEventType
            return lambda: since(1, 0xFFFFFFFF)
    except (AttributeError, OSError):
        pass
    return lambda: None


_os_idle_seconds = _make_os_idle_seconds()


def idle_seconds():
    """Seconds without input or changes in Blender."""
    blender_idle = time.perf_counter() - _last_activity
    os_idle = _os_idle_seconds()
    return blender_idle if os_idle is None else min(blender_idle, os_idle)


@persistent
def _on_change(*_args):
    if not player.state.busy():
        touch()


def _free_capturer():
    global _offscreen_owner
    if _offscreen_owner is not None:
        _offscreen_owner.free()
        _offscreen_owner = None


def _interactive_modal_running():
    """True while a transform, modal tool or similar runs (and the mouse may be still).

    Some add-ons keep a modal operator running all the time; those that have been
    running for BACKGROUND_MODAL_AGE seconds are ignored.
    """
    now = time.perf_counter()
    seen = {}
    for window in bpy.context.window_manager.windows:
        for operator in window.modal_operators:
            pointer = operator.as_pointer()
            seen[pointer] = _modal_seen.get(pointer, now)
    _modal_seen.clear()
    _modal_seen.update(seen)
    return any(now - first < BACKGROUND_MODAL_AGE for first in seen.values())


def _job_running():
    for job in _BLOCKING_JOBS:
        try:
            if bpy.app.is_job_running(job):
                return True
        except (TypeError, ValueError):
            pass
    return False


def _target():
    """(window, area) of the 3D Viewport to cache from: the last one used, else the biggest."""
    wanted = store.frame_cache.area_ptr
    best = None
    for window in bpy.context.window_manager.windows:
        for area in window.screen.areas:
            if area.type != 'VIEW_3D':
                continue
            if area.as_pointer() == wanted:
                return window, area
            if best is None or area.width * area.height > best[1].width * best[1].height:
                best = (window, area)
    return best


def _step(window, area, region, space):
    """Cache one missing frame. Returns True when a frame was cached."""
    global _offscreen_owner
    if bpy.context.mode not in _ALLOWED_MODES:
        return False
    scene = window.scene
    cache = store.frame_cache
    capturer = capture.Capturer(scene, window.view_layer, region, space, scene.cache_play.preview_size)
    if capturer.key != cache.key:
        if not cache.is_empty():
            return False  # a cache of another view: leave it for the user to replace
        if capturer.mode != 'CAMERA' and capturer.key != cache.last_key:
            return False  # only rebuild a free view the user cached before
        cache.prepare(capturer.key, scene.name, capturer.width, capturer.height, capturer.mode,
                      area.as_pointer())

    first, last = scene_range(scene)
    current = min(max(scene.frame_current, first), last)
    _in_ram, cached = cache.snapshot()
    order = [*range(current, last + 1), *range(first, current)]
    frame = next((f for f in order if f not in cached), None)
    if frame is None or not cache.has_room(frame):
        return False

    # Fresh view references every step (layouts change); only the GPU buffer is reused.
    if _offscreen_owner is not None and (_offscreen_owner.width, _offscreen_owner.height) == (
            capturer.width, capturer.height):
        capturer.offscreen, _offscreen_owner.offscreen = _offscreen_owner.offscreen, None
    _free_capturer()
    _offscreen_owner = capturer

    state = player.state
    state.idle_step = True
    try:
        original = scene.frame_current, scene.frame_subframe
        scene.frame_set(frame)
        cache.put(frame, capturer.capture(bpy.context.evaluated_depsgraph_get()))
        scene.frame_set(original[0], subframe=original[1])
    finally:
        state.idle_step = False
        state.suppress(0.3)
    store.tag_time_editors()
    return True


def _tick():
    try:
        return _tick_unsafe()
    except Exception as ex:
        print(f"Cache Play idle caching: {ex}")
        _free_capturer()
        return 2.0


def _view_moved(space):
    """True when the viewport was orbited, panned or zoomed since the last check."""
    global _last_view
    rv3d = space.region_3d
    view = (tuple(map(tuple, rv3d.view_matrix)), rv3d.view_distance, rv3d.view_camera_zoom,
            tuple(rv3d.view_camera_offset))
    moved = _last_view is not None and view != _last_view
    _last_view = view
    return moved


def _tick_unsafe():
    interactive = _interactive_modal_running()
    found = _target()
    if found is None or not found[0].scene.cache_play.cache_when_idle:
        _free_capturer()
        return 1.0
    window, area = found
    region, space = capture.view3d_parts(area)
    if region is None:
        return 1.0
    if _view_moved(space):
        touch()
    state = player.state
    wm = bpy.context.window_manager
    if (interactive or state.active or state.filling
            or idle_seconds() < get_prefs().idle_delay
            or any(w.screen.is_animation_playing for w in wm.windows)
            or _job_running()):
        _free_capturer()
        return CHECK_INTERVAL
    configure_cache()
    with bpy.context.temp_override(window=window, area=area, region=region):
        cached = _step(window, area, region, space)
    if not cached:
        _free_capturer()
        return 1.0
    return 0.0  # next frame right away; mouse events in between still stop it


@persistent
def _on_load_pre(*_args):
    global _last_view
    _free_capturer()
    _last_view = None
    touch()


_HANDLERS = (
    ("depsgraph_update_post", _on_change),
    ("frame_change_post", _on_change),
    ("load_pre", _on_load_pre),
)


def register():
    touch()
    for name, func in _HANDLERS:
        getattr(bpy.app.handlers, name).append(func)
    bpy.app.timers.register(_tick, first_interval=1.0, persistent=True)


def unregister():
    if bpy.app.timers.is_registered(_tick):
        bpy.app.timers.unregister(_tick)
    for name, func in _HANDLERS:
        handlers = getattr(bpy.app.handlers, name)
        if func in handlers:
            handlers.remove(func)
    _free_capturer()
