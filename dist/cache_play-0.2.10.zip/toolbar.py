# SPDX-License-Identifier: GPL-3.0-or-later
"""Floating Cache Play toolbar over the 3D Viewport.

Built from gizmos, the same kind of on-screen buttons as Blender's navigation controls, so
it needs no running operator (which would block autosave) and works in every 3D Viewport.
A row of round buttons sits near the bottom centre; drag the grip on its left to move it.
The position is kept in the add-on preferences as an offset from the bottom centre.
"""

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix

from . import player, store
from .ui import get_prefs

BUTTON = 30       # button diameter, px at UI scale 1
GAP = 4
GRIP_WIDTH = 14
MARGIN = 14       # distance from the bottom edge
IDLE_COLOR = (0.10, 0.10, 0.10)
ACTIVE_COLOR = (1.0, 0.62, 0.15)  # the cache playhead's colour

# (operator, icon); Cache Mode is lit while it is on.
BUTTONS = (
    ("cacheplay.preview", 'PLAY'),
    ("cacheplay.cache_mode", 'FILE_MOVIE'),
    ("cacheplay.clear", 'TRASH'),
    ("cacheplay.settings", 'PREFERENCES'),
)


def _scale():
    return bpy.context.preferences.system.ui_scale


def toolbar_geometry(region):
    """Where the toolbar sits in region pixels: (left, centre y, button size, gap, grip width)."""
    s = _scale()
    size, gap, grip = BUTTON * s, GAP * s, GRIP_WIDTH * s
    width = grip + gap + len(BUTTONS) * (size + gap)
    offset_x, offset_y = get_prefs().toolbar_offset
    left = region.width / 2 - width / 2 + offset_x * s
    y = MARGIN * s + size / 2 + offset_y * s
    # Keep it inside the viewport when the area shrinks.
    left = min(max(left, 4 * s), max(4 * s, region.width - width - 4 * s))
    y = min(max(y, size / 2 + 4 * s), max(size / 2 + 4 * s, region.height - size / 2 - 4 * s))
    return left, y, size, gap, grip


def _rects(rects, color):
    coords, indices = [], []
    for x0, y0, x1, y1 in rects:
        k = len(coords)
        coords += ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
        indices += ((k, k + 1, k + 2), (k, k + 2, k + 3))
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices=indices)
    shader.uniform_float("color", color)
    batch.draw(shader)


class CACHEPLAY_GT_grip(bpy.types.Gizmo):
    """Drag handle on the left of the toolbar; also draws the cached-frames count on the right."""
    bl_idname = "CACHEPLAY_GT_grip"
    __slots__ = ("start_mouse", "start_offset")

    def _grip_rect(self, context):
        left, y, size, _gap, grip = toolbar_geometry(context.region)
        return left, y - size / 2, left + grip, y + size / 2

    def draw(self, context):
        x0, y0, x1, y1 = self._grip_rect(context)
        s = _scale()
        gpu.state.blend_set('ALPHA')
        alpha = 0.85 if self.is_highlight or self.is_modal else 0.55
        _rects([(x0, y0 + 2 * s, x1, y1 - 2 * s)], (*IDLE_COLOR, alpha * 0.8))
        dot = 2 * s
        cx = (x0 + x1) / 2
        dots = [(cx + dx - dot / 2, (y0 + y1) / 2 + dy - dot / 2, cx + dx + dot / 2, (y0 + y1) / 2 + dy + dot / 2)
                for dx in (-2.5 * s, 2.5 * s) for dy in (-5 * s, 0, 5 * s)]
        _rects(dots, (0.85, 0.85, 0.85, alpha))
        self._draw_status(context)
        gpu.state.blend_set('NONE')

    def _draw_status(self, context):
        left, y, size, gap, grip = toolbar_geometry(context.region)
        right = left + grip + gap + len(BUTTONS) * (size + gap)
        first, last = store.scene_range(context.scene)
        _in_ram, cached = store.frame_cache.snapshot()
        done = len(cached.intersection(range(first, last + 1)))
        text = f"{done}/{last - first + 1}"
        s = _scale()
        blf.size(0, 11 * s)
        _w, h = blf.dimensions(0, text)
        blf.enable(0, blf.SHADOW)
        blf.shadow(0, 3, 0.0, 0.0, 0.0, 0.9)
        blf.shadow_offset(0, 1, -1)
        blf.color(0, 1.0, 1.0, 1.0, 0.85)
        blf.position(0, right + 2 * s, y - h / 2, 0)
        blf.draw(0, text)
        blf.disable(0, blf.SHADOW)

    def test_select(self, context, location):
        x, y = location
        x0, y0, x1, y1 = self._grip_rect(context)
        return 0 if x0 <= x <= x1 and y0 <= y <= y1 else -1

    def invoke(self, context, event):
        self.start_mouse = (event.mouse_region_x, event.mouse_region_y)
        self.start_offset = tuple(get_prefs().toolbar_offset)
        return {'RUNNING_MODAL'}

    def modal(self, context, event, tweak):
        s = _scale()
        prefs = get_prefs()
        prefs.toolbar_offset = (
            self.start_offset[0] + (event.mouse_region_x - self.start_mouse[0]) / s,
            self.start_offset[1] + (event.mouse_region_y - self.start_mouse[1]) / s,
        )
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def exit(self, context, cancel):
        if cancel:
            get_prefs().toolbar_offset = self.start_offset
        context.area.tag_redraw()


class VIEW3D_GGT_cache_play(bpy.types.GizmoGroup):
    bl_idname = "VIEW3D_GGT_cache_play"
    bl_label = "Cache Play Toolbar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        return get_prefs(context).toolbar in {'VIEWPORT', 'BOTH'}

    def setup(self, context):
        self.buttons = []
        for operator, icon in BUTTONS:
            gz = self.gizmos.new("GIZMO_GT_button_2d")
            gz.icon = icon
            gz.draw_options = {'BACKDROP', 'OUTLINE'}
            gz.color = IDLE_COLOR
            gz.alpha = 0.7
            gz.color_highlight = (0.3, 0.3, 0.3)
            gz.alpha_highlight = 0.9
            gz.target_set_operator(operator)
            self.buttons.append(gz)
        self.grip = self.gizmos.new(CACHEPLAY_GT_grip.bl_idname)

    def draw_prepare(self, context):
        left, y, size, gap, grip = toolbar_geometry(context.region)
        x = left + grip + gap + size / 2
        for gz in self.buttons:
            gz.scale_basis = BUTTON / 2  # Blender applies the UI scale to this itself
            gz.matrix_basis = Matrix.Translation((x, y, 0.0))
            x += size + gap
        state = player.state
        lit = (state.active and not state.cache_mode, state.cache_mode, False, False)
        for gz, on in zip(self.buttons, lit):
            gz.color = ACTIVE_COLOR if on else IDLE_COLOR
            gz.alpha = 0.95 if on else 0.7


classes = (CACHEPLAY_GT_grip, VIEW3D_GGT_cache_play)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
