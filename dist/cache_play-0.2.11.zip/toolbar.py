# SPDX-License-Identifier: GPL-3.0-or-later
"""Floating Cache Play toolbar over the 3D Viewport.

Built from gizmos, the same kind of on-screen buttons as Blender's navigation controls, so
it needs no running operator (which would block autosave) and works in every 3D Viewport.
A row of round buttons sits near the bottom centre; drag the grip on its left to move it.
The position is kept in the add-on preferences as an offset from the bottom centre.
"""

import math

import blf
import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from mathutils import Matrix

from . import player, store
from .ui import get_prefs

BUTTON = 28       # button diameter, px at UI scale 1
GAP = 2
GRIP_WIDTH = 14
INSET = 3         # pill edge to buttons
TEXT_GAP = 6      # last button to the cached count
MARGIN = 14       # distance from the bottom edge
PILL_COLOR = (0.11, 0.11, 0.11, 0.88)
PILL_EDGE = (0.30, 0.30, 0.30, 0.90)
HOVER_COLOR = (0.32, 0.32, 0.32)
ACTIVE_COLOR = (1.0, 0.62, 0.15)  # the cache playhead's colour
FONT_SIZE = 11

# (operator, icon); Cache Mode is lit while it is on.
BUTTONS = (
    ("cacheplay.preview", 'PLAY'),
    ("cacheplay.cache_mode", 'FILE_MOVIE'),
    ("cacheplay.clear", 'TRASH'),
    ("cacheplay.settings", 'PREFERENCES'),
)


def _scale():
    return bpy.context.preferences.system.ui_scale


_button_state = []  # (under the mouse, switched on) per button, set in draw_prepare


def _status_text(context):
    first, last = store.scene_range(context.scene)
    _in_ram, cached = store.frame_cache.snapshot()
    done = len(cached.intersection(range(first, last + 1)))
    return f"{done}/{last - first + 1}"


class Geometry:
    """Where the pill and its parts sit, in region pixels."""

    def __init__(self, context):
        region = context.region
        s = _scale()
        self.size = BUTTON * s
        self.gap = GAP * s
        self.text = _status_text(context)
        blf.size(0, FONT_SIZE * s)
        self.text_w, self.text_h = blf.dimensions(0, self.text)
        inset = INSET * s
        self.height = self.size + 2 * inset
        width = (inset + GRIP_WIDTH * s + len(BUTTONS) * (self.size + self.gap)
                 + TEXT_GAP * s + self.text_w + self.height / 2)
        offset_x, offset_y = get_prefs().toolbar_offset
        left = region.width / 2 - width / 2 + offset_x * s
        y = MARGIN * s + self.height / 2 + offset_y * s
        # Keep it inside the viewport when the area shrinks.
        margin = 4 * s
        left = min(max(left, margin), max(margin, region.width - width - margin))
        y = min(max(y, self.height / 2 + margin), max(self.height / 2 + margin, region.height - self.height / 2 - margin))
        self.left, self.right, self.y = left, left + width, y
        self.grip = (left + inset, left + inset + GRIP_WIDTH * s)
        self.first_button_x = self.grip[1] + self.gap + self.size / 2
        self.text_x = self.first_button_x + len(BUTTONS) * (self.size + self.gap) - self.size / 2 + TEXT_GAP * s

    def contains(self, x, y):
        return self.left <= x <= self.right and abs(y - self.y) <= self.height / 2


def _rects(rects, color):
    coords, indices = [], []
    for x0, y0, x1, y1 in rects:
        k = len(coords)
        coords += ((x0, y0), (x1, y0), (x1, y1), (x0, y1))
        indices += ((k, k + 1, k + 2), (k, k + 2, k + 3))
    _fill(coords, indices, color)


def _fill(coords, indices, color):
    shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    batch = batch_for_shader(shader, 'TRIS', {"pos": coords}, indices=indices)
    shader.uniform_float("color", color)
    batch.draw(shader)


def _pill(x0, x1, y, height, color, segments=12):
    """A rectangle with fully round ends."""
    r = height / 2
    points = []
    for i in range(segments + 1):  # right end, bottom to top
        a = -math.pi / 2 + math.pi * i / segments
        points.append((x1 - r + r * math.cos(a), y + r * math.sin(a)))
    for i in range(segments + 1):  # left end, top to bottom
        a = math.pi / 2 + math.pi * i / segments
        points.append((x0 + r + r * math.cos(a), y + r * math.sin(a)))
    coords = [((x0 + x1) / 2, y)] + points
    indices = [(0, i, i + 1) for i in range(1, len(points))] + [(0, len(points), 1)]
    _fill(coords, indices, color)


class CACHEPLAY_GT_grip(bpy.types.Gizmo):
    """The pill behind the buttons: drawn first, dragged by its grip or its count."""
    bl_idname = "CACHEPLAY_GT_grip"
    __slots__ = ("start_mouse", "start_offset")

    def draw(self, context):
        geo = Geometry(context)
        s = _scale()
        gpu.state.blend_set('ALPHA')
        _pill(geo.left - s, geo.right + s, geo.y, geo.height + 2 * s, PILL_EDGE)
        _pill(geo.left, geo.right, geo.y, geo.height, PILL_COLOR)
        # Grip: two columns of dots.
        alpha = 0.95 if self.is_highlight or self.is_modal else 0.5
        dot = 2 * s
        cx = (geo.grip[0] + geo.grip[1]) / 2
        dots = [(cx + dx - dot / 2, geo.y + dy - dot / 2, cx + dx + dot / 2, geo.y + dy + dot / 2)
                for dx in (-2.5 * s, 2.5 * s) for dy in (-5 * s, 0, 5 * s)]
        _rects(dots, (0.9, 0.9, 0.9, alpha))
        # Round backgrounds behind the icons: orange while on, grey under the mouse. The
        # buttons draw icons only, because Blender fades a button's icon with its background.
        radius = geo.size / 2
        for i, (hover, on) in enumerate(_button_state):
            if hover or on:
                x = geo.first_button_x + i * (geo.size + geo.gap)
                _pill(x - radius, x + radius, geo.y, geo.size, ACTIVE_COLOR + (0.95,) if on else HOVER_COLOR + (0.9,))
        blf.size(0, FONT_SIZE * s)
        blf.color(0, 0.9, 0.9, 0.9, 0.9)
        blf.position(0, geo.text_x, geo.y - geo.text_h / 2, 0)
        blf.draw(0, geo.text)
        gpu.state.blend_set('NONE')

    def test_select(self, context, location):
        """Grab by the grip or by the count; the buttons take clicks on themselves."""
        x, y = location
        geo = Geometry(context)
        if not geo.contains(x, y):
            return -1
        on_grip = x <= geo.grip[1] + geo.gap / 2
        on_count = x >= geo.text_x - TEXT_GAP * _scale() / 2
        return 0 if on_grip or on_count else -1

    def invoke(self, context, event):
        self.start_mouse = (event.mouse_region_x, event.mouse_region_y)
        self.start_offset = tuple(get_prefs().toolbar_offset)
        return {'RUNNING_MODAL'}

    def modal(self, context, event, tweak):
        s = _scale()
        prefs = get_prefs()
        prefs.toolbar_offset = (
            self.start_offset[0] + (event.mouse_region_x - self.start_mouse[0]) / s,
            self.start_offset[1] + (event.mouse_region_y - self.start_mouse[1]) / s,
        )
        context.area.tag_redraw()
        return {'RUNNING_MODAL'}

    def exit(self, context, cancel):
        if cancel:
            get_prefs().toolbar_offset = self.start_offset
        context.area.tag_redraw()


class VIEW3D_GGT_cache_play(bpy.types.GizmoGroup):
    bl_idname = "VIEW3D_GGT_cache_play"
    bl_label = "Cache Play Toolbar"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'WINDOW'
    bl_options = {'PERSISTENT', 'SCALE'}

    @classmethod
    def poll(cls, context):
        return get_prefs(context).toolbar in {'VIEWPORT', 'BOTH'}

    def setup(self, context):
        self.buttons = []
        for operator, icon in BUTTONS:
            gz = self.gizmos.new("GIZMO_GT_button_2d")
            gz.icon = icon
            gz.draw_options = set()  # icon only; the pill draws the round backgrounds
            gz.color = gz.color_highlight = (1.0, 1.0, 1.0)
            gz.alpha = gz.alpha_highlight = 1.0
            gz.target_set_operator(operator)
            self.buttons.append(gz)
        # Blender draws a group's gizmos newest first, so the pill, made last, ends up behind.
        self.grip = self.gizmos.new(CACHEPLAY_GT_grip.bl_idname)

    def draw_prepare(self, context):
        geo = Geometry(context)
        x = geo.first_button_x
        for gz in self.buttons:
            gz.scale_basis = BUTTON / 2  # Blender applies the UI scale to this itself
            gz.matrix_basis = Matrix.Translation((x, geo.y, 0.0))
            x += geo.size + geo.gap
        state = player.state
        lit = (state.active and not state.cache_mode, state.cache_mode, False, False)
        _button_state[:] = [(gz.is_highlight, on) for gz, on in zip(self.buttons, lit)]


classes = (CACHEPLAY_GT_grip, VIEW3D_GGT_cache_play)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)


def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
